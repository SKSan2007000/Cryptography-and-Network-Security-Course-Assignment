from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from pathlib import Path
from .crypto_engine import *
import json, time, uuid

app=FastAPI(title='EHR Integrity & Signature Lab', version='1.0')
ROOT=Path(__file__).resolve().parent.parent
INDEX=(ROOT/'static'/'index.html').read_text(encoding='utf-8')
KEYS={}; AUDIT=[]
DEMO={
 'patient_id':'EHR-DEMO-001','patient_name':'Asha Raman','date':'2026-08-31','provider':'Dr. Meera Iyer','facility':'Sentinel Telehealth Centre','diagnosis':'Acute respiratory infection','prescription':'Amoxicillin 500 mg — as prescribed','lab_summary':'CRP mildly elevated; oxygen saturation 97%','sensitivity':'RESTRICTED'
}
class SignReq(BaseModel): record:dict; hash_algorithm:str='SHA-256'; scheme:str='ECDSA-P256'; signer:str='Dr. Meera Iyer'; role:str='Physician'
class VerifyReq(BaseModel): record:dict; digest:str; signature:str; public_key:str; scheme:str='ECDSA-P256'; hash_algorithm:str='SHA-256'

@app.get('/',response_class=HTMLResponse)
def home(): return INDEX

@app.get('/api/demo')
def demo(): return {'record':DEMO}

@app.post('/api/keys')
def keys(scheme='ECDSA-P256'):
    priv,pub=gen_keys(scheme); kid='KEY-'+uuid.uuid4().hex[:8].upper(); KEYS[kid]={'private':priv,'public':pub,'scheme':scheme,'created':time.time()}
    AUDIT.append({'event':'KEY_GENERATED','key_id':kid,'scheme':scheme,'timestamp':time.strftime('%Y-%m-%d %H:%M:%S')})
    return {'key_id':kid,'public_key':pub,'private_key':priv,'scheme':scheme}

@app.post('/api/sign')
def sign(req:SignReq):
    raw=canonicalize(req.record); digest=hash_record(raw,req.hash_algorithm)
    priv,pub=gen_keys(req.scheme); sig=sign_digest_hex(digest,priv,req.scheme)
    sid='SIG-'+uuid.uuid4().hex[:10].upper()
    AUDIT.append({'event':'DOCUMENT_SIGNED','signature_id':sid,'signer':req.signer,'role':req.role,'hash':req.hash_algorithm,'scheme':req.scheme,'digest':digest,'timestamp':time.strftime('%Y-%m-%d %H:%M:%S')})
    return {'signature_id':sid,'digest':digest,'signature':sig,'public_key':pub,'private_key':priv,'scheme':req.scheme,'hash_algorithm':req.hash_algorithm,'canonical_bytes':len(raw)}

@app.post('/api/verify')
def verify(req:VerifyReq):
    raw=canonicalize(req.record); current=hash_record(raw,req.hash_algorithm); match=(current==req.digest)
    sig_ok=verify_digest_hex(current,req.signature,req.public_key,req.scheme)
    valid=match and sig_ok
    AUDIT.append({'event':'VERIFICATION','result':'VALID' if valid else 'REJECTED','hash_match':match,'signature_valid':sig_ok,'timestamp':time.strftime('%Y-%m-%d %H:%M:%S')})
    return {'valid':valid,'hash_match':match,'signature_valid':sig_ok,'current_digest':current,'expected_digest':req.digest}

@app.post('/api/tamper')
def tamper_api(record:dict): return {'tampered_record':tamper(record)}

@app.post('/api/benchmark')
def bench(record:dict): return {'bytes':len(canonicalize(record)),'results':benchmark(canonicalize(record),300)}

@app.get('/api/audit')
def audit(): return {'events':AUDIT[-50:]}

@app.get('/api/health')
def health(): return {'status':'ok','service':'EHR Crypto Lab'}
