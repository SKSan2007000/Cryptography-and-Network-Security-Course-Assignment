import sys, pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from app.crypto_engine import *

def test_hashes():
    d=b'hello EHR'
    assert len(hash_record(d,'SHA-256'))==64
    assert len(hash_record(d,'SHA-3-256'))==64
    assert len(hash_record(d,'BLAKE2b-256'))==64

def test_ecdsa_roundtrip():
    priv,pub=gen_keys('ECDSA-P256'); digest=hash_record(b'patient record','SHA-256'); sig=sign_digest_hex(digest,priv,'ECDSA-P256'); assert verify_digest_hex(digest,sig,pub,'ECDSA-P256'); assert not verify_digest_hex(hash_record(b'tampered','SHA-256'),sig,pub,'ECDSA-P256')

def test_ed25519_roundtrip():
    priv,pub=gen_keys('Ed25519'); digest=hash_record(b'patient record','SHA-256'); sig=sign_digest_hex(digest,priv,'Ed25519'); assert verify_digest_hex(digest,sig,pub,'Ed25519')
